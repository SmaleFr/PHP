<?php
  require("config/commandes.php");
  $Produits=afficher();

?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8">
    <title>Panier</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
  </head>
  
  <style>
body {
   display: flex;
   flex-direction: column;
   justify-content: center;
   align-items: center;
   height: 100vh;
   background: #85C1E9;
   font-family: 'Open Sans', sans-serif;
   color: #fff;
}
select {
   -webkit-appearance:none;
   -moz-appearance:none;
   -ms-appearance:none;
   appearance:none;
   outline:0;
   box-shadow:none;
   border:0!important;
   background: #5c6664;
   background-image: none;
   flex: 1;
   padding: 0 .5em;
   color:#fff;
   cursor:pointer;
   font-size: 1em;
   font-family: 'Open Sans', sans-serif;
}
select::-ms-expand {
   display: none;
}
.select {
   position: relative;
   display: flex;
   width: 20em;
   height: 3em;
   line-height: 3;
   background: #5c6664;
   overflow: hidden;
   border-radius: .25em;
}
.select::after {
   content: '\25BC';
   position: absolute;
   top: 0;
   right: 0;
   padding: 0 1em;
   background: #2b2e2e;
   cursor:pointer;
   pointer-events:none;
   transition:.25s all ease;
}
.select:hover::after {
   color: #23b499;
}

.login-box .user-box {
  position: relative;
}

.login-box .user-box input {
  width: 100%;
  padding: 25px 0px;
  font-size: 16px;
  color: #fff;
  margin-bottom: 30px;
  border: none;
  border-bottom: 1px solid #fff;
  outline: none;
  background: transparent;
}

.login-box .user-box label {
  position: absolute;
  top: 0;
  left: 0;
  padding: 10px 0px;
  font-size: 16px;
  color: #fff;
  pointer-events: none;
  transition: .5s;
}

.login-box .user-box input:focus ~ label,
.login-box .user-box input:valid ~ label {
  top: 0px;
  left: 0;
  color: #000000;
  font-size: 12px;
}
.login-box form a {
  position: relative;
  display: inline-block;
  padding: 10px 20px;
  color: #ffffff;
  font-size: 16px;
  text-decoration: none;
  text-transform: uppercase;
  overflow: hidden;
  transition: .5s;
  margin-top: 40px;
  letter-spacing: 4px
}

.login-box a:hover {
  background: #537992;
  color: #fff;
  border-radius: 5px;
  box-shadow: 0 0 5px #537992,
              0 0 25px #537992,
              0 0 50px #537992,
              0 0 100px #537992;
}

.login-box a span {
  position: absolute;
  display: block;
}

@keyframes btn-anim1 {
  0% {
    left: -100%;
  }

  50%,100% {
    left: 100%;
  }
}

.login-box a span:nth-child(1) {
  bottom: 2px;
  left: -100%;
  width: 100%;
  height: 2px;
  background: linear-gradient(90deg, transparent, #537992);
  animation: btn-anim1 2s linear infinite;
}
  </style>
<body>
    <h1>Choisissez votre vélo</h1>

    <form action="confirmation.php" method="post">
    <select name="produit">
    <option selected disabled>Sélectionnez votre vélo</option>
    <?php foreach ($Produits as $produit): ?>
        <option value="<?= $produit->id ?>"><?= $produit->nom ?></option>
    <?php endforeach; ?>
</select>



        <div class="user-box">
            <input type="text" name="nom" required>
            <label>Nom</label>
        </div>

        <div class="user-box">
            <input type="text" name="prenom" required>
            <label>Prénom</label>
        </div>

        <div class="user-box">
            <input type="text" name="email" required>
            <label>Email</label>
        </div>

        <div class="user-box">
            <input type="text" name="message" required>
            <label>Message</label>
        </div>

        <button type="submit">Acheter</button>
    </form>
</body>

</html>