<?php

function afficher()
{
    require("rooter.php");

    try {
        $req = $access->prepare("SELECT * FROM vélos ORDER BY id DESC");
        $req->execute();
        $data = $req->fetchAll(PDO::FETCH_OBJ);
        $req->closeCursor();  // Placer cette ligne avant le return
        return $data;
    } catch (PDOException $e) {
        echo "Erreur : " . $e->getMessage();
        return false;  // En cas d'erreur, retourner false ou un autre indicateur
    }
}

function lastvelos()
{
    require("rooter.php");

    try {
        $req = $access->prepare("SELECT * FROM vélos ORDER BY id DESC LIMIT 1");
        $req->execute();
        $data = $req->fetchAll(PDO::FETCH_OBJ);
        $req->closeCursor();  // Placer cette ligne avant le return
        return $data;
    } catch (PDOException $e) {
        echo "Erreur : " . $e->getMessage();
        return false;  // En cas d'erreur, retourner false ou un autre indicateur
    }
}

?>