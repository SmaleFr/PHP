<?php

try {
    $access = new PDO('mysql:host=127.0.0.1;dbname=smartbike;charset=utf8;port=8889', "root", "root");
    // Remplacez "votre_nom_utilisateur" et "votre_mot_de_passe" par votre nom d'utilisateur et mot de passe MySQL.
}
catch (PDOException $e) {
    echo "Erreur de connexion : " . $e->getMessage();
}

?>
