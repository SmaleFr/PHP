<?php
include 'config/rooter.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nom = mysqli_real_escape_string($acces, $_POST['nom']);
    $prenom = mysqli_real_escape_string($acces, $_POST['prenom']);
    $email = mysqli_real_escape_string($acces, $_POST['email']);
    $message = mysqli_real_escape_string($acces, $_POST['message']);

    // Assurez-vous d'avoir une table 'achat' avec les colonnes nécessaires
    $preparer = "INSERT INTO achat (nom, prenom, email, message) VALUES ('$nom', '$prenom', '$email', '$message')";
    $execution = mysqli_query($acces, $preparer);

    if ($execution) {
        echo "Achat réussi";
    } else {
        echo "Echec de l'achat : " . mysqli_error($acces);
    }
}
?>
