<?php

try {
$host = '51.158.59.186:14301';
$db = 'EL';
$user = 'phppex';
$pass = 'supermotdepasse!42';

    $access = new PDO('mysql:host=$host;dbname=$db', $user, $pass);
}
catch (PDOException $e) {
    echo "Erreur de connexion : " . $e->getMessage();
}

?>
